package com.challenge;

public class Cat extends Pet {
private String Catcolor;
	
	public Cat(String name, int age, String breed, String catColor) {
        super(name, age, breed, "CAT");
    }


}
