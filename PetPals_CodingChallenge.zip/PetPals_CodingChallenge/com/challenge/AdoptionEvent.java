package com.challenge;

import java.util.ArrayList;
import java.util.List;

public class AdoptionEvent {
	private List<IAdoptable> participants;

    public AdoptionEvent() {
        this.participants = new ArrayList<>();
    }

    // Method to host the adoption event
    public void hostEvent() {
        System.out.println("Adoption event hosted!");
        // Perform any additional actions related to hosting the event
    }

    // Method to register a participant for the event
    public void registerParticipant(IAdoptable participant) {
        participants.add(participant);
        System.out.println("Participant registered for the adoption event.");
    }
}


