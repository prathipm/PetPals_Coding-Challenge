package com.challenge;

public interface IAdoptable {
	void adopt();

}
